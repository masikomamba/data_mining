# Checkpoint 2 evidence index

All results were created by the appended Checkpoint 2 cells. Use the CSV tables for exact numerical results and the PNG figures for report figures.

## Key analyses
- Tables 01�04 / Figures 01�02: sample integrity, rare categories, distributions, missingness and tails
- Tables 05�08 / Figure 03: linear regression, robust/classical coefficient tests, adjusted slopes and predictions
- Tables 09�15 / Figure 04: VIF, variance and normality diagnostics, residual trends, influence, repeated VINs
- Tables 16�17 / Figure 05: quadratic comparison, robust joint test, mileage-dependent slopes
- Tables 18�19 / Figure 06: five group-disjoint split seeds and out-of-sample performance
- Table 20 / Figure 07: sensitivity of mileage interaction to filtering and influential cases
- Table 21: assumptions and what cannot be tested from listings alone

## Important interpretation limits
- The null of the primary regression test is zero mileage-by-type interaction, not equal mean prices.
- Classical exact t assumptions are more restrictive than large-sample HC3 Wald inference.
- Significant diagnostics can indicate misspecification but do not identify a single correct new model.
- Results are cross-sectional asking-price associations, not causal depreciation.
